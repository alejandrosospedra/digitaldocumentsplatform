package IG;

import java.awt.*;
import java.io.*;

import javax.swing.*;

import dades.*;

public class BuscarRevistaSegonsTitolIG extends JFrame{
	private static final long serialVersionUID = 1L;
	private LlistaRevistes llistaRevistes = new LlistaRevistes(20);
	private JPanel panellPregunta;
	private JTextField texte;
	private JLabel pregunta;
	private JTextArea infoRevistes;
	/**
	 * Constructor de la finestra del buscador de la revista
	 * segons el titol especificat per l'usuari
	 * @param titol - titol de la finestra
	 */
	public BuscarRevistaSegonsTitolIG (String titol) {
		super(titol);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(600, 350);
		setLocation(500, 200);
		
		texte = new JTextField(15);
		panellPregunta = new JPanel();
		
		Container meuCont = getContentPane();
		meuCont.setLayout(new BorderLayout());
	
		panellPregunta.setLayout(new FlowLayout());
		pregunta = new JLabel("De quin titol vols la info de la revista? ");
		panellPregunta.add(pregunta);
		panellPregunta.add(texte);
		
		AccioDelTextFieldR accioTextField = new AccioDelTextFieldR(this);
		texte.addActionListener(accioTextField);
		
		meuCont.add(panellPregunta, BorderLayout.SOUTH);
		
		infoRevistes = new JTextArea("Info de la revista: \n");
		
		meuCont.add(infoRevistes, BorderLayout.CENTER);
		
		setVisible(true);
		
	}
	/**
	 * Metode per mostrar la revista en un text area segons el titol
	 * @param titol - titol de la revista�
	 */
	public void MostrarRevistaSegonsTitol (String titol) throws IOException {
		boolean trobat = false;
		FitxerDocDigital.llegirRevistes(llistaRevistes);
		int i=0;
		while(i<llistaRevistes.getNumRevistes() && !trobat) {
			if(llistaRevistes.getRevista(i).getTitol().equals(titol)) {
				infoRevistes.append(llistaRevistes.getRevista(i).toString()+"\n");
				trobat = true;
			}else {
				i++;
			}
		}
		if(!trobat)
			infoRevistes.append("No hi ha cap revista amb aquest titol.\n");
	}

}
