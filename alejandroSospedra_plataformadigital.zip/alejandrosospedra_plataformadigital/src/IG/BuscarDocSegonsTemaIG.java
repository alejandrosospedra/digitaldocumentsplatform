package IG;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.io.IOException;

import javax.swing.*;

public class BuscarDocSegonsTemaIG extends JFrame{
	private static final long serialVersionUID = 1L;
	private JPanel panellPregunta;
	private JTextField texte;
	private JLabel pregunta;
	/**
	 * Constructor del buscador de documents segons el tema
	 * @param titol - titlol de la finestra
	 */
	public BuscarDocSegonsTemaIG (String titol) {
		super(titol);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(500, 250);
		setLocation(500, 200);

		texte = new JTextField(7);
		panellPregunta = new JPanel();
		
		Container meuCont = getContentPane();
		meuCont.setLayout(new BorderLayout());
	
		panellPregunta.setLayout(new FlowLayout());
		pregunta = new JLabel("De quin tema vols la info dels documents digitals? ");
		panellPregunta.add(pregunta);
		panellPregunta.add(texte);
		
		AccioDelTextFieldDoc accioTextField = new AccioDelTextFieldDoc(this);
		texte.addActionListener(accioTextField);
		
		meuCont.add(panellPregunta, BorderLayout.CENTER);
		
		setVisible(true);
		
	}
	/**
	 * Metode que crida a la finestra graella documents
	 * per mostrar els documents en forma de botons de un tema
	 * @param tema - tema dels documents especificat per l'usuari
	 */
	public void MostrarDocSegonsTema (String tema) throws IOException {
		new GraellaDocumentsIG("DOCUMENTS SEGONS TEMA", tema);
		setVisible(false);
	
	}

}
