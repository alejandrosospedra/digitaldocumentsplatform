package IG;

import java.awt.*;

import java.io.*;

import javax.swing.*;

public class MenuIG extends JFrame{
	
		private static final long serialVersionUID = 1L;
		private JButton BuscLsegonsTitol;
		private JButton BuscRsegonsTitol;
		private JButton BuscRevistaMesEx;
		private JButton BuscDocSegonsTema;
		private JButton BuscRevistaMesExAny;
		private JButton Sortir;
		private JPanel botons;
		
		/**
		 * Constructor de la interface Menu client. Crea una finestra per consultar llibres i/o revistes.
		 * @param titol - titol de la finestra
		 */
		public MenuIG(String titol) {
			super(titol);
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			setSize(350, 250);
			setLocation(500, 200);

			Container meuCont = getContentPane();
			meuCont.setLayout(new BorderLayout());

			AccioBotonsMenuIG accioBoto = new AccioBotonsMenuIG(this);

			botons = new JPanel();
			botons.setLayout(new FlowLayout());
			BuscLsegonsTitol = new JButton("Buscar llibre segons el titol");
			BuscRsegonsTitol = new JButton("Buscar revista segons el titol");
			BuscRevistaMesEx = new JButton("Buscar revista amb mes exemplars");
			BuscDocSegonsTema = new JButton("Buscar document digital segons el tema");
			BuscRevistaMesExAny= new JButton("Buscar revista amb mes exemplars segons l'any");
			Sortir = new JButton("Sortir");
			botons.add(BuscLsegonsTitol);
			botons.add(BuscRsegonsTitol);
			botons.add(BuscRevistaMesEx);
			botons.add(BuscDocSegonsTema);
			botons.add(BuscRevistaMesExAny);
			meuCont.add(botons, BorderLayout.CENTER);
			meuCont.add(Sortir, BorderLayout.SOUTH);
			BuscLsegonsTitol.addActionListener(accioBoto);
			BuscRsegonsTitol.addActionListener(accioBoto);
			BuscRevistaMesEx.addActionListener(accioBoto);
			BuscDocSegonsTema.addActionListener(accioBoto);
			BuscRevistaMesExAny.addActionListener(accioBoto);
			Sortir.addActionListener(accioBoto);

			setVisible(true);
		}


		/**
		* M�tode per obrir la finestra del buscador de llibres segons 
		* el titol
		*/
		public void BuscarLLibreSegonsTitol() {
			new BuscarLlibreSegonsTitolIG ("BUSCAR LLIBRE SEGONS TITOL");
			setVisible(false);
		}
		/**
		* M�tode per obrir la finestra del buscador de revistes segons el 
		* titol
		*/
		public void BuscarRevistaSegonsTitol() {
			new BuscarRevistaSegonsTitolIG ("BUSCAR REVISTA SEGONS TITOL");
			setVisible(false);
		}

		/**
		 * M�tode per obrir la finestra del buscador de la revista amb
		 * mes exemplars
		 */
		public void BuscarRevistaMesExemplars() throws IOException {
			new BuscaRevistaMesExemplarsIG ("BUSCAR REVISTA AMB MES EXEMPLARS");
			setVisible(false);
		}

		/**
		 * M�tode per obrir la finestra del buscador de documents digitals
		 * de un tema
		 */
		public void BuscarDocSegonsTemaIG() {
			new BuscarDocSegonsTemaIG("CONSULTAR DOCUMENT SEGONS TEMA");
			setVisible(false);
		}
		
		/**
		 * M�tode per obrir la finestra del buscador de la revista
		 * amb mes exemplars de un any especificat
		 */
		public void BuscarRevistaMesExemplarsEnAnyIG() {
			new BuscarRevistaMesExemplarsEnAnyIG("CONSULTAR DOCUMENT SEGONS TEMA");
			setVisible(false);
		}

		/**
		 * M�tode per sortir de l'aplicaci�.
		 */
		public void Sortir() {
			int opcio = JOptionPane.showConfirmDialog(null, "Segur que vols sortir?", "CONFIRMACI�", JOptionPane.YES_NO_OPTION);
			if (opcio == JOptionPane.YES_OPTION) {
				System.exit(0);
			} 
		}
		/**
		 * Main de la interficie grafica
		 */
		public static void main(String[] args) {
			new MenuIG("MENU");

		}
}
