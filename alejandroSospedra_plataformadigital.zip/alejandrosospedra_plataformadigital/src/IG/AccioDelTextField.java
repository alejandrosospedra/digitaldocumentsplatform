package IG;

import java.awt.event.*;
import java.io.IOException;

import javax.swing.JTextField;

public class AccioDelTextField implements ActionListener{
	private BuscarLlibreSegonsTitolIG finestra;
	/**
	 * Constructor de la classe de accions per buscar un llibre segons el titol
	 * @param finestra - finestra del buscador
	 */
	public AccioDelTextField (BuscarLlibreSegonsTitolIG finestra) {
		this.finestra = finestra;
	}
	/**
	 * Metode que llegeix el titol especificat per l'usuari en el text field
	 */
	public void actionPerformed(ActionEvent e) {
		JTextField tf = (JTextField) e.getSource();
		String s = tf.getText();
		try {
			finestra.MostrarLlibresSegonsTitol(s);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}
