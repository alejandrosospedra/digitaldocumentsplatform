package IG;

import java.awt.*;

import java.awt.event.*;

import javax.swing.JButton;

public class AccioBoto implements ActionListener{
	/**
	 * M�tode per "simular" una descarrega de un document digital
	 */
	public void actionPerformed(ActionEvent e) {
		  JButton boto=(JButton) e.getSource();
		  boto.setBackground(Color.GREEN);
	}

}
