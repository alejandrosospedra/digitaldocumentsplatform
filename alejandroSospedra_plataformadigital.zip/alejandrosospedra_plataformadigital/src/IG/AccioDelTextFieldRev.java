package IG;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JTextField;

public class AccioDelTextFieldRev implements ActionListener{
	private BuscarRevistaMesExemplarsEnAnyIG finestra;
	/**
	 * Constructor de les acciones de la finstra amb mes exemplars 
	 * en un any especificat
	 * @param finestra - finestra del buscador
	 */
	public AccioDelTextFieldRev(BuscarRevistaMesExemplarsEnAnyIG finestra) {
		this.finestra=finestra;
	}
	/**
	 * Metode per llegir l'any del text field de la finestra
	 * del buscador
	 */
	public void actionPerformed(ActionEvent e) {
		JTextField tf = (JTextField) e.getSource();
		int any =Integer.parseInt(tf.getText());
		try {
			finestra.MostrarRevistesSegonsAny(any);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	
	
	
}
