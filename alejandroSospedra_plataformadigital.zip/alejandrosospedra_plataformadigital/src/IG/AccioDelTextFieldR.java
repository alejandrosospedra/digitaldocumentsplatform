package IG;

import java.awt.event.*;
import java.io.IOException;

import javax.swing.JTextField;

public class AccioDelTextFieldR implements ActionListener{
	private BuscarRevistaSegonsTitolIG finestra;
	/**
	 * Constructor de les accions de la finestra del buscador de 
	 * revistes segons el titol
	 * @param finestra - finestra del buscador
	 */
	public AccioDelTextFieldR (BuscarRevistaSegonsTitolIG finestra) {
		this.finestra = finestra;
	}
	/**
	 * Metode per llegir el titol especificat per l'usuari
	 * en el text field de la finestra
	 */
	public void actionPerformed(ActionEvent e) {
		JTextField tf = (JTextField) e.getSource();
		String s = tf.getText();
		try {
			finestra.MostrarRevistaSegonsTitol(s);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}
