package IG;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class BuscarRevistaMesExemplarsEnAnyIG extends JFrame{

	private static final long serialVersionUID = 1L;
	private JPanel panellPregunta;
	private JTextField texte;
	private JLabel pregunta;
	/**
	 * Constructo de la finestra del buscador de la revista amb mes exemplars
	 * segons l'any especificat
	 * @param titol - titol de la finestra
	 */
	public BuscarRevistaMesExemplarsEnAnyIG (String titol) {
		super(titol);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(500, 250);
		setLocation(500, 200);

		texte = new JTextField(7);
		panellPregunta = new JPanel();
		
		Container meuCont = getContentPane();
		meuCont.setLayout(new BorderLayout());
	
		panellPregunta.setLayout(new FlowLayout());
		pregunta = new JLabel("De quin any vols consultar les revistes? ");
		panellPregunta.add(pregunta);
		panellPregunta.add(texte);
		
		AccioDelTextFieldRev accioTextField = new AccioDelTextFieldRev(this);
		texte.addActionListener(accioTextField);
		
		meuCont.add(panellPregunta, BorderLayout.CENTER);
		
		setVisible(true);
		
	}
	/**
	 * Metode per cridar a la finestra graella revistes
	 * que mostra les revistes en forma de botons segons l'any
	 * @param any - any de publicacio de la revista especificat per l'usuari
	 */
	public void MostrarRevistesSegonsAny (int any) throws IOException {
		new GraellaRevistesIG("REVISTES SEGONS ANY", any);
		setVisible(false);
	
	}
	

}
