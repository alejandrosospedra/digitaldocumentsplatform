package IG;
 
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;

public class AccioBotonsMenuIG implements ActionListener{
	MenuIG finestra;
	/**
	 * Constructor de la classe de les accions del botons de la classe menu
	 * @param referencia - Referencia de la finestra del menu
	 *
	 */
	public AccioBotonsMenuIG(MenuIG referencia) {
		finestra = referencia;
	}
	/**
	 * M�tode que controla les accions dels botons del menu
	 */
	public void actionPerformed(ActionEvent e){
		JButton boto = (JButton) e.getSource();
		String cas = boto.getText();
		
		if (cas.equals("Buscar llibre segons el titol")) {
			finestra.BuscarLLibreSegonsTitol();
		} else if(cas.equals("Buscar revista segons el titol")){
			finestra.BuscarRevistaSegonsTitol();
		} else if(cas.equals("Buscar revista amb mes exemplars")) {
			try {
				finestra.BuscarRevistaMesExemplars();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} else if(cas.equals("Buscar document digital segons el tema")) {
			finestra.BuscarDocSegonsTemaIG();
		} else if(cas.equals("Buscar revista amb mes exemplars segons l'any")) {
			finestra.BuscarRevistaMesExemplarsEnAnyIG();
		} else {
			finestra.Sortir();
		}
		
	}
}
