package IG;

import java.awt.*;
import java.io.*;

import javax.swing.*;

import dades.*;

public class GraellaRevistesIG extends JFrame{
	private static final long serialVersionUID = 1L;
	private LlistaRevistes llistaRevistes = new LlistaRevistes(20);
	private JButton[] llista;
	private JPanel panellBotons;
	/**
	 * Constructor de la finestra que mostra la graella de revistes
	 * publicades en un any especificat
	 * @param titol - titol de la finestra
	 * @param any - any de publicacio
	 */
	public GraellaRevistesIG(String titol, int any) throws IOException {
		super(titol);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(500, 250);
		setLocation(500, 200);

		Container meuCont = getContentPane();
		meuCont.setLayout(new BorderLayout());

		panellBotons = new JPanel();

		FitxerDocDigital.llegirRevistes(llistaRevistes);
		
		int mida = llistaRevistes.getNumRevistes();
		llista=new JButton[mida];
		panellBotons.setLayout(new GridLayout(mida, 0));
		
		AccioBoto accioBoto = new AccioBoto();
	
		for(int j=0; j<llistaRevistes.getNumRevistes(); j++) {
			if(llistaRevistes.getRevista(j).getLlistaExemplars().existeixEnAny(any)) {
					llista[j] = new JButton(llistaRevistes.getRevista(j).getTitol());
					llista[j].setBackground(Color.white);	
					llista[j].addActionListener(accioBoto);
					panellBotons.add(llista[j]);
			}
		}
		
		meuCont.add(panellBotons, BorderLayout.NORTH);	
		
		setVisible(true);
	}

}
