package IG;

import java.awt.*;
import java.io.IOException;

import javax.swing.*;
import dades.*;

public class BuscarLlibreSegonsTitolIG extends JFrame{
	private static final long serialVersionUID = 1L;
	private LlistaLlibres llistaLlibres = new LlistaLlibres(20);
	private JPanel panellPregunta;
	private JTextField texte;
	private JLabel pregunta;
	private JTextArea infoLlibres;
	/**
	 * Constructor de la finestra del buscador de un llibre segons el seu titol
	 * @param titol - titol de la finestra
	 */
	public BuscarLlibreSegonsTitolIG (String titol) {
		super(titol);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(400, 250);
		setLocation(500, 200);
		
		texte = new JTextField(15);
		panellPregunta = new JPanel();
		
		Container meuCont = getContentPane();
		meuCont.setLayout(new BorderLayout());
	
		panellPregunta.setLayout(new FlowLayout());
		pregunta = new JLabel("De quin titol vols la info del llibre? ");
		panellPregunta.add(pregunta);
		panellPregunta.add(texte);
		
		AccioDelTextField accioTextField = new AccioDelTextField(this);
		texte.addActionListener(accioTextField);
		
		meuCont.add(panellPregunta, BorderLayout.SOUTH);
		
		infoLlibres = new JTextArea("Info del llibre: \n");
		
		meuCont.add(infoLlibres, BorderLayout.CENTER);
		
		setVisible(true);
		
	}
	/**
	 * Metode per mostrar en un text area la informacio de un llibre
	 * segons el titol especificat per l'usuari
	 * @param titol - titol del que volem el llibre
	 */
	public void MostrarLlibresSegonsTitol (String titol) throws IOException {
		boolean trobat = false;
		FitxerDocDigital.llegirLlibres(llistaLlibres);
		int i = 0;
		while( i<llistaLlibres.getNumLlibres() && !trobat) {
			if(llistaLlibres.getLlibre(i).getTitol().equals(titol)) {
				infoLlibres.append(llistaLlibres.getLlibre(i).toString()+"\n");
				trobat = true;
			}else i++;	
		}
		if(!trobat)
			infoLlibres.append("No hi ha cap llibre amb aquest titol.\n");
	}

}
