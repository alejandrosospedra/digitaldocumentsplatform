package IG;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

import dades.*;

public class GraellaDocumentsIG extends JFrame{

	private static final long serialVersionUID = 1L;
	private LlistaRevistes llistaRevistes = new LlistaRevistes(20);
	private LlistaLlibres llistaLlibres = new LlistaLlibres(20);
	private JButton[] llista;
	private JPanel panellBotons;
	/**
	 * Constructor de la finestra de la graella amb els documents trobats segons
	 * un tema
	 * @param titol - titol de la finestra
	 * @param tema - tema del document
	 * @throws IOException
	 */
	public GraellaDocumentsIG(String titol, String tema) throws IOException {
		super(titol);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(500, 250);
		setLocation(500, 200);

		Container meuCont = getContentPane();
		meuCont.setLayout(new BorderLayout());

		panellBotons = new JPanel();

		FitxerDocDigital.llegirLlibres(llistaLlibres);
		FitxerDocDigital.llegirRevistes(llistaRevistes);
		int mida = llistaRevistes.getNumRevistes()+llistaLlibres.getNumLlibres();
		llista=new JButton[mida];
		panellBotons.setLayout(new GridLayout(mida, 0));
		AccioBoto accioBoto = new AccioBoto();
		
		int i;
		for(i=0; i<llistaLlibres.getNumLlibres(); i++) {
			if(llistaLlibres.getLlibre(i).getTemes().conteTema(tema)) {
				llista[i] = new JButton(llistaLlibres.getLlibre(i).getTitol());
				llista[i].setBackground(Color.WHITE);
				llista[i].addActionListener(accioBoto);
				panellBotons.add(llista[i]);
			}
			
		}
		for(int j=0; j<llistaRevistes.getNumRevistes(); j++) {
			if(llistaRevistes.getRevista(j).getTemes().conteTema(tema)) {
					llista[j+i] = new JButton(llistaRevistes.getRevista(j).getTitol());
					llista[j+i].setBackground(Color.white);	
					llista[j+i].addActionListener(accioBoto);
					panellBotons.add(llista[j+i]);
			}
		}
		
		meuCont.add(panellBotons, BorderLayout.NORTH);	
		
		setVisible(true);
	}
	
}

