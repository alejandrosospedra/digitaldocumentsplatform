package IG;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import javax.swing.*;

public class AccioDelTextFieldDoc implements ActionListener{
	private BuscarDocSegonsTemaIG finestra;
	/**
	 * Constructor de les accions del buscador de documents digitals segons el tema
	 * @param finestra - finestra del buscador
	 */
	public AccioDelTextFieldDoc (BuscarDocSegonsTemaIG finestra) {
		this.finestra = finestra;
	}
	/**
	 * Metode per llegir el tema especificat per l'usuari en el text field 
	 * de la finestra del buscador
	 */
	public void actionPerformed(ActionEvent e) {
		JTextField tf = (JTextField) e.getSource();
		String s = tf.getText();
		try {
			finestra.MostrarDocSegonsTema(s);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
}
