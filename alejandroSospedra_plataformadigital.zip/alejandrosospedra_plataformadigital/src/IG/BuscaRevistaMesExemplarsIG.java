package IG;
import java.awt.*;
import java.io.IOException;

import javax.swing.*;

import dades.*;

public class BuscaRevistaMesExemplarsIG extends JFrame{
	private static final long serialVersionUID = 1L;
	private LlistaRevistes llistaRevistes;
	private JTextArea infoRevista;

	/**
	 * Constructor de la finestra que fa de buscador de la revista amb mes exemplars
	 * @param titol - titol de la finestra
	 */
	public BuscaRevistaMesExemplarsIG (String titol) throws IOException {
		super(titol);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(400, 250);
		setLocation(500, 200);
		
		Container meuCont = getContentPane();
		meuCont.setLayout(new BorderLayout());
	
		infoRevista = new JTextArea("Info de la revista amb m�s exemplars: \n");
		
		meuCont.add(infoRevista, BorderLayout.CENTER);
		
		mostrarRevistaMesExemplars();
		
		setVisible(true);
		
	}
	/**
	 * Metode que mostra en un text area la informacio de la revista amb mes exemplars
	 */
	public void mostrarRevistaMesExemplars() throws IOException {
		int mesExemplars=0;
		Revista revistaMesExemplars = null;
		llistaRevistes = new LlistaRevistes(20);
		FitxerDocDigital.llegirRevistes(llistaRevistes);
		
		for(int i=0; i<llistaRevistes.getNumRevistes(); i++) {
			if(llistaRevistes.getRevista(i).getLlistaExemplars().getNumExemplars()>mesExemplars) {
				mesExemplars = llistaRevistes.getRevista(i).getLlistaExemplars().getNumExemplars();
				revistaMesExemplars = llistaRevistes.getRevista(i).copia();
			}
		}
		try {
			infoRevista.append(revistaMesExemplars.toString()+"\n");
		}catch(NullPointerException e) {
			infoRevista.append("\nNo hi han exemplars");
		}
	}
}
