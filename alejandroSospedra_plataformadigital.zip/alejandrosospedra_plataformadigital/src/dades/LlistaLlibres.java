package dades;

public class LlistaLlibres {
	
	private Llibre[] llistaLlibres;
	private int numLlibres=0;
	
	/**
	 * Constructor de la llista de llibres
	 * @param mida de la llista
	 */
	public LlistaLlibres(int mida) {
		llistaLlibres= new Llibre[mida];
	}
	/**
	 * Getter
	 * @return llista de llibres
	 */
	public Llibre[] getLlistaLlibres() {
		return llistaLlibres;
	}
	
	/**
	 * Setter
	 * @param llista de Llibres
	 */
	public void setLlistaLlibres(Llibre[] llistaLlibres) {
		this.llistaLlibres = llistaLlibres;
	}
	/**
	 * Getter
	 * @return numero de llibres
	 */
	public int getNumLlibres() {
		return numLlibres;
	}
	/**
	 * Setter
	 * @param numero de llibres
	 */
	public void setNumLlibres(int numLlibres) {
		this.numLlibres = numLlibres;
	}
	/**
	 * Metode per afegir un llibre a la llista
	 * @param llibre
	 */
	public void afegirLlibre(Llibre llibre) {
		int pos;
		try {		
			llistaLlibres[numLlibres] = llibre;
			numLlibres++;
		} catch (ArrayIndexOutOfBoundsException e) {
			Llibre[] aux = new Llibre[numLlibres * 2];
			
			for (pos = 0; pos < numLlibres; pos++) 
				aux[pos] = llistaLlibres[pos];
			aux[pos] =llibre;
			llistaLlibres = aux;
			numLlibres++;
		}
	}
	/**
	 * Metode per rebre una copia del llibre en la posicio indicada
	 * @param posicio de la llista
	 * @return llibre
	 */
	public Llibre getLlibre(int pos) {
		try {
			return(llistaLlibres[pos].copia());
		}catch (NullPointerException e) {
			System.out.println("No hi ha cap llibre en aquesta posici�");
			return null;
		}
	}
	/**
	 * Metode per mostrar la informacio de tots els llibres de la llista
	 */
	public String toString() {
		String aux= "LLISTA DE LLIBRES: N�mero de llibres==> " +numLlibres+ "\n"; 
		for(int i=0; i<numLlibres; i++)
			aux = aux + "\n" +llistaLlibres[i].toString()+ "\n";
		return(aux);
	}
}
