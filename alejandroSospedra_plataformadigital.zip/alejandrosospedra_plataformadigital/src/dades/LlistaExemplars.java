package dades;

public class LlistaExemplars {
	
	private Exemplar[] llistaExemplars;
	private int numExemplars=0;
	/**
	 * Constructor de la llista de exemplars
	 * @param mida de la llista
	 */
	public LlistaExemplars(int mida) {
		llistaExemplars= new Exemplar[mida];
	}
	/**
	 * Getter
	 * @return llista de exemplars
	 */
	public Exemplar[] getLlistaExemplars() {
		return llistaExemplars;
	}
	/**
	 * Setter
	 * @param llista Exemplars
	 */
	public void setLlistaExemplars(Exemplar[] llistaExemplars) {
		this.llistaExemplars = llistaExemplars;
	}
	/**
	 * Getter
	 * @return numero de exemplars
	 */
	public int getNumExemplars() {
		return numExemplars;
	}
	/**
	 * Setter
	 * @param num Exemplars
	 */
	public void setNumExemplars(int numExemplars) {
		this.numExemplars = numExemplars;
	}
	/**
	 * Metode per comprobar si l'exemplar va estar publicat
	 * en l'any especificat per parametre
	 * @param any de publicacio
	 * @return si existeix true sino false
	 */
	public boolean existeixEnAny(int any) {
		boolean existeix=false;
		int i=0;
		while(i<numExemplars && !existeix) {
			if(llistaExemplars[i].getAny()==any)
				existeix=true;
			else
				i++;
		}
		return(existeix);
	}
	/**
	 * Metode per afegir un exemplar
	 * @param exemplar
	 */
	public void afegirExemplar(Exemplar exemplar) {
		int pos;
		try {		
			llistaExemplars[numExemplars] = exemplar;
			numExemplars++;
		} catch (ArrayIndexOutOfBoundsException e) {
			Exemplar[] aux = new Exemplar[numExemplars * 2];
			
			for (pos = 0; pos < numExemplars; pos++) 
				aux[pos] = llistaExemplars[pos];
			aux[pos] = exemplar;
			llistaExemplars = aux;
			numExemplars++;
		}
	}
	/**
	 * Metode per rebre una copia d'un exemplar de una posicio de la llista
	 * @param posicio
	 * @return exemplar
	 */
	public Exemplar getExemplar(int pos) {
		try {
			return(llistaExemplars[pos].copia());
		}catch (NullPointerException e) {
			System.out.println("No hi ha cap exemplar en aquesta posici�");
			return null;
		}
	}
	/**
	 * Metode per motrar els atributs de llista exemplars
	 */
	public String toString() {
		String aux= "LLISTA DE EXEMPLARS: N�mero de Exemplars==> " +numExemplars+ "\n"; 
		for(int i=0; i<numExemplars; i++)
			aux = aux + "\n" +llistaExemplars[i].toString() + "\n";
		return(aux);
	}

}
