package dades;

public abstract class DocumentsDigitals {
	
	protected String titol;
	protected LlistaTemes temes;
	
	/**
	 * Constructor per defecte
	 * @param temes
	 */
	public DocumentsDigitals(LlistaTemes temes) {
		titol="";
		this.temes=temes;
	}
	/**
	 * Constructor de la clase pare Documents Digitals on guardem el titol y els temes
	 * d'una revista o un llibre
	 * @param titol
	 * @param temes
	 */
	public DocumentsDigitals(String titol, LlistaTemes temes) {
		this.titol=titol;
		this.temes=temes;
	}
	/**
	 * Getter
	 * @return direcci� del llistat de temes
	 */
	public LlistaTemes getTemes() {
		return temes;
	}
	/**
	 * Setter
	 * @param llistat de temes d'un document digital
	 */
	public void setTemes(LlistaTemes temes) {
		this.temes = temes;
	}
	/**
	 * Getter
	 * @return titol del document digital
	 */
	public String getTitol() {
		return titol;
	}
	/**
	 * Setter
	 * @param titol del document digital
	 */
	public void setTitol(String titol) {
		this.titol = titol;
	}

}
