package dades;

public class LlistaTemes {
	
	private static final int numMaxTemes = 20;
	private static int contadorTemesDiferents=0;
	private int numTemes = 0;
	private static String[] totalDeTemesDiferents = new String[numMaxTemes];
	private String[] temes;
	/**
	 * constructor de la llista de temes amb el numero maxim permes
	 */
	public LlistaTemes() {
		temes = new String[numMaxTemes];
	}
	/**
	 * Metode per afegir un tema a la llista
	 * @param tema
	 */
	public void afegirTema(String tema) {
		try {
			temes[numTemes] = tema;
			if (!existeixTema(tema) && contadorTemesDiferents<numMaxTemes) {
				totalDeTemesDiferents[contadorTemesDiferents] = tema;
				contadorTemesDiferents++;
			}
			numTemes++;
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("No es poden afegir m�s temes");
		}
	}
	/**
	 * Metode que retorna true si existeix el tema indicat per parametre
	 * en la llista de tots els temes diferents i fals si no.
	 * @param tema
	 * @return existeix=[true(si existeix)/fals(no)]
	 */
	private boolean existeixTema(String tema) {
		boolean existeix = false;
		
		for (int i = 0; i<contadorTemesDiferents; i++) {
			if(totalDeTemesDiferents[i].equals(tema))
					existeix = true;
		}
		return existeix;
	}
	/**
	 * Metode que retorna true si existeix el tema indicat per parametre
	 * en la llista de temes i fals si no.
	 * @param tema
	 * @return existeix=[true(si existeix)/fals(no)]
	 */
	public boolean 	conteTema(String tema) {
		boolean existeix = false;
		int i = 0;
		while(i<numTemes && !existeix) {
			if (temes[i].equals(tema))
				existeix=true;
			else
				i++;
		}
		
		return existeix;
	}
	/**
	 * Getter
	 * @return numero de temes
	 */
	public int getNumTemes() {
		return numTemes;
	}
	/**
	 * Setter
	 * @param numero de temes
	 */
	public void setNumTemes(int numTemes) {
		this.numTemes = numTemes;
	}
	/**
	 * Metode que retorna un tema de la llista segons la 
	 * posicio indicada per parametre
	 * @param posicio de la llista
	 * @return tema de la posicio de la llista
	 */
	public String getTema(int pos) {
		return(temes[pos]);
	}
	/**
	 * Metode per mostrar els temes de la llista
	 */
	public String toString() {
		String aux = "Temes: ";
		aux = aux + temes[0];
		for(int i = 1; i<numTemes; i++) {
			aux= aux + ","+temes[i];
		}
		return aux;
	}

}
