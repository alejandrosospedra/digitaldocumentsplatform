package dades;

public class Revista extends DocumentsDigitals{
	
	private final static String tipusId= "REVISTA_";
	private static int contadorId=0;
	private String codiId;
	private String periodicitat;
	private LlistaExemplars llistaExemplars;
	/**
	 * Constructor general de una revista on s'inicialitza tot en blanc
	 * @param temes en els que es classifica la revista
	 */
	public Revista(LlistaTemes temes) {
		super(temes);
		periodicitat="";
		setCodiId("");
	}
	/**
	 * Constructor de una revista per afegirla a una llista sense exemplars
	 * @param titol ==>de la revista
	 * @param temes ==>en els que es pot classificar
	 * @param periodicitat de publicacio de la revista
	 */
	public Revista(String titol, LlistaTemes temes, String periodicitat) {
		super(titol, temes);
		contadorId++;
		setCodiId(tipusId+contadorId);
		this.periodicitat=periodicitat;
		llistaExemplars = new LlistaExemplars(10);
	}
	/**
	 * Constructor de una revista per afegirla a una llista amb exemplars
	 * @param titol ==>de la revista
	 * @param temes ==>en els que es pot classificar
	 * @param periodicitat de publicacio de la revista
	 *@param llista de exemplars de la revista
	 */
	public Revista(String titol, LlistaTemes temes, String periodicitat, LlistaExemplars llista) {
		super(titol, temes);
		contadorId++;
		setCodiId(tipusId+contadorId);
		this.periodicitat=periodicitat;
		llistaExemplars=llista;
	}
	/**
	 * Constructor de una revista per fer una copia, no s'incrementa el contador de revistes
	 * @param titol ==>de la revista
	 * @param temes ==>en els que es pot classificar
	 * @param periodicitat de publicacio de la revista
	 * @param codi identificador de la revista
	 * @param llista de exemplars de la revista
	 */
	public Revista(String titol, LlistaTemes temes, String periodicitat, String codiId, LlistaExemplars llista) {
		super(titol, temes);
		this.periodicitat=periodicitat;
		llistaExemplars=llista;
		setCodiId(codiId);
	}	
	/**
	 * Constructor de una revista per llegirla d'un fitxer, s'increnmenta el contador de revistes
	 * @param codi identificador
	 * @param titol
	 * @param temes
	 * @param periodicitat
	 * @param llista de exemplars
	 */
	public Revista(String codiId, String titol, LlistaTemes temes, String periodicitat, LlistaExemplars llista) {
		super(titol, temes);
		this.periodicitat=periodicitat;
		llistaExemplars=llista;
		setCodiId(codiId);
		contadorId++;
	}
	/**
	 * Getter
	 * @return codi identificador
	 */
	public String getCodiId() {
		return codiId;
	}
	/**
	 * Setter 
	 * @param codi identificador
	 */
	public void setCodiId(String codiId) {
		this.codiId = codiId;
	}
	/**
	 * Getter
	 * @return periodicitat de publicacio
	 */
	public String getPeriodicitat() {
		return periodicitat;
	}
	/**
	 * Setter
	 * @param periodicitat
	 */
	public void setPeriodicitat(String periodicitat) {
		this.periodicitat = periodicitat;
	}
	/**
	 * Getter
	 * @return llista de exemplars
	 */
	public LlistaExemplars getLlistaExemplars() {
		return llistaExemplars;
	}
	/**
	 * Setter
	 * @param llista de Exemplars
	 */
	public void setLlistaExemplars(LlistaExemplars llistaExemplars) {
		this.llistaExemplars = llistaExemplars;
	}
	/**
	 * Getter
	 * @return tipus de identificador(llibre o revista)
	 */
	public static String getTipusid() {
		return tipusId;
	}
	/**
	 * Metode per mostrar tota la informacio de una revista
	 */
	public String toString() {
		String aux;
		aux="Codi identificador: "+getCodiId()+"\nTitol: "+super.titol+"\nPeriodicitat: "+periodicitat+"\n"+super.temes.toString();
		aux = aux + "\n\n"+llistaExemplars.toString();
		return(aux);
	}
	/**
	 * Metode per mostrar la informacio general de una revista,
	 * es a dir, sense els seus exemplars
	 */
	public String toStringInfoGeneral() {
		return("Codi identificador: "+getCodiId()+"\nTitol: "+super.titol+"\nPeriodicitat: "+periodicitat+"\n"+super.temes.toString());
	}
	/**
	 * Metode per retornar una copia de la revista
	 * @return revista
	 */
	public Revista copia() {
		return(new Revista (getTitol(), temes, periodicitat,  codiId, llistaExemplars));
	}

}
