package dades;

public class DataNoValidaExcepcio extends Exception {
	private static final long serialVersionUID = 1L;
	/**
	 * Constructor de la excepcio de data no valida per a un any superior a 2018
	 */
	public DataNoValidaExcepcio () {
		super("\nHA DE SER UN MES DEL 1 AL 12, Y L'ANY ABANS DEL 2019!");
	}

}
