package dades;

import java.io.*;
import java.util.*;

public class FitxerDocDigital {
	/**
	 * Metode per llegir del fitxer Llibres.txt una llista de llibres
	 * @param llista de llibres
	 * @throws IOException
	 */
	public static void llegirLlibres(LlistaLlibres l) throws IOException {
		try {
			BufferedReader lectura = new BufferedReader(new FileReader("Llibres.txt"));
			String linia, titol, autor, codiId;
			LlistaTemes temes;
			
			linia = lectura.readLine();
			while (linia != null) {
				StringTokenizer st = new StringTokenizer(linia, ",");
				try {
					codiId = st.nextToken();
					titol = st.nextToken();
					autor = st.nextToken();
					temes = new LlistaTemes();
					while(st.hasMoreTokens()) {
						temes.afegirTema(st.nextToken());
					}
					l.afegirLlibre(new Llibre(codiId,titol, temes, autor));
					linia = lectura.readLine();
				} catch (NoSuchElementException e) {
					System.out.println("\nFitxer de llibres buit.\n");
				}
			}

			lectura.close();

		} catch (FileNotFoundException e) {
			System.out.println("Fitxer LLibres.txt no trobat.\n");
		} catch (IOException e) {
			System.out.println("Error d'E/S en el fitxer de llibres.\n");
		}
	}
	/**
	 *Metode per escriure una llista de llibres al fitxer Llibres.txt 
	 * @param llista de llibres
	 * @throws IOException
	 */
	public static void escriureLlibres(LlistaLlibres l) throws IOException {
		BufferedWriter sortida = new BufferedWriter(new FileWriter("Llibres.txt"));

		for (int i = 0; i < l.getNumLlibres(); i++) {
			sortida.write(l.getLlibre(i).getCodiId() + "," + l.getLlibre(i).getTitol() + ","
					+ l.getLlibre(i).getAutor());
			for(int j = 0; j < l.getLlibre(i).temes.getNumTemes(); j++) {
				sortida.write("," + l.getLlibre(i).temes.getTema(j));
			}
			sortida.newLine();
		}

		sortida.close();
	}
	/**
	 * Metode per llegir del fitxer Revistes.txt una llista de revistes
	 * @param llista de revistes
	 * @throws IOException
	 */
	public static void llegirRevistes(LlistaRevistes r) throws IOException {
		try {
			BufferedReader lectura = new BufferedReader(new FileReader("Revistes.txt"));
			String linia, titol, periodicitat, codiId;
			LlistaTemes temes;
			LlistaExemplars llistaE;
			int numExemplars, any, mes, numEx;
			

			linia = lectura.readLine();
			while (linia != null) {
				StringTokenizer st = new StringTokenizer(linia, ",");
				try {
					codiId = st.nextToken();
					titol = st.nextToken();
					periodicitat = st.nextToken();
					numExemplars= Integer.parseInt(st.nextToken());
					if (numExemplars==0) 
						llistaE = new LlistaExemplars(10);
					else
						llistaE = new LlistaExemplars(numExemplars);
					for(int j=0; j<numExemplars; j++) {
						numEx = Integer.parseInt(st.nextToken());
						any = Integer.parseInt(st.nextToken());
						mes = Integer.parseInt(st.nextToken());
						llistaE.afegirExemplar(new Exemplar(any, mes, numEx, numExemplars));
					}
					temes = new LlistaTemes();
					while(st.hasMoreTokens()) {
						temes.afegirTema(st.nextToken());
					}
					r.afegirRevista(new Revista(codiId,titol, temes, periodicitat, llistaE));
					linia = lectura.readLine();
				} catch (NoSuchElementException e) {
					System.out.println("\nFitxer de revistes buit.\n");
				}
			}

			lectura.close();

		} catch (FileNotFoundException e) {
			System.out.println("Fitxer Revistes.txt no trobat.\n");
		} catch (IOException e) {
			System.out.println("Error d'E/S en el fitxer de revistes.\n");
		}
	}
	/**
	 * Metode per escriure una llista de revistes al fitxer Revistes.txt 
	 * @param r
	 * @throws IOException
	 */
	public static void escriureRevista(LlistaRevistes r) throws IOException {
		BufferedWriter sortida = new BufferedWriter(new FileWriter("Revistes.txt"));

		for (int i = 0; i < r.getNumRevistes(); i++) {
			sortida.write(r.getRevista(i).getCodiId() + "," + r.getRevista(i).getTitol() + ","
					+ r.getRevista(i).getPeriodicitat());
			sortida.write("," + r.getRevista(i).getLlistaExemplars().getNumExemplars());
			for(int j= 0; j< r.getRevista(i).getLlistaExemplars().getNumExemplars(); j++) {
				sortida.write("," + r.getRevista(i).getLlistaExemplars().getExemplar(j).getNumExemplar() + ","
						 + r.getRevista(i).getLlistaExemplars().getExemplar(j).getAny() + ","
						 + r.getRevista(i).getLlistaExemplars().getExemplar(j).getMes());
			}
			for(int k = 0; k < r.getRevista(i).temes.getNumTemes(); k++) {
				sortida.write("," + r.getRevista(i).temes.getTema(k));
			}
			sortida.newLine();
		}

		sortida.close();
	}
}