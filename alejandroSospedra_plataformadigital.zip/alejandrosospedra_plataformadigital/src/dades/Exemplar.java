package dades;

public class Exemplar {
	
	private int any;
	private int mes;
	private static int numExemplars=0;
	private int numExemplar=0;
	/**
	 * Constructor de un exemplar d'una revista on guardem l'any i el mes de publicaci�
	 * @param any
	 * @param mes
	 */
	public Exemplar(int any, int mes) {
		this.any=any;
		this.mes=mes;
		numExemplars++;
		numExemplar=numExemplars;
	}
	
	/**
	 * Constructor d'un exemplar d'una revista per generar copies d'aquest ja que,
	 * no es modifica el numero de exemplar
	 * @param any
	 * @param mes
	 * @param numExemplar
	 */
	
	public Exemplar(int any, int mes, int numExemplar) {
		this.any=any;
		this.mes=mes;
		this.numExemplar=numExemplar;
	}
	/**
	 * Constructor d'un exemplar d'una revista per llegir-lo d'un fitxer ja que,
	 * es mante el numero de exemplar del fitxer i a mes mantenim el numero
	 * de exemplars que tenim per al afegir un altre tenir correctessa en el numero
	 * @param any
	 * @param mes
	 * @param numExemplar
	 * @param numExemplars
	 */
	public Exemplar(int any, int mes, int numExemplar, int numExemplars) {
		this.any=any;
		this.mes=mes;
		this.numExemplar=numExemplar;
		Exemplar.numExemplars=numExemplars;
	}
	/**
	 * Setter
	 * @param numero de exemplar
	 */
	public void setNumExemplar(int numExemplar) {
		this.numExemplar = numExemplar;
	}
	/**
	 * Getter
	 * @return any de publicacio
	 */
	public int getAny() {
		return any;
	}
	/**
	 * Setter
	 * @param any de publicacio
	 */
	public void setAny(int any) {
		this.any = any;
	}
	/**
	 * Getter
	 * @return mes de publicacio
	 */
	public int getMes() {
		return mes;
	}
	/**
	 * Setter
	 * @param mes de publicacio
	 */
	public void setMes(int mes) {
		this.mes = mes;
	}
	/**
	 * Getter
	 * @return numero de exemplar
	 */
	public int getNumExemplar() {
		return numExemplar;
	}
	/**
	 * Metode toString per mostrar per pantalla el contingut de l'exemplar
	 */
	public String toString() {
		return("Exemplar n�mero: " +numExemplar+ "\nAny: " +any+ "\nMes: " +mes);
	}
	/**
	 * Metode de copia de un exemplar
	 * @return copia de l'exemplar
	 */
	public Exemplar copia() {
		return( new Exemplar(any, mes, numExemplar));
	}

}
