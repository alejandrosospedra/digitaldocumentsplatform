package dades;

public class LlistaRevistes {
	
	private Revista[] llistaRevistes;
	private int numRevistes;
	/**
	 * Constructor de la llista de revistes
	 * @param mida de la llista
	 */
	public LlistaRevistes(int mida) {
		llistaRevistes= new Revista[mida];
	}
	/**
	 * Getter
	 * @return llista de revistes
	 */
	public Revista[] getLlistaRevistes() {
		return llistaRevistes;
	}
	/**
	 * Setter
	 * @param llista de revistes
	 */
	public void setLlistaRevistes(Revista[] llistaRevistes) {
		this.llistaRevistes = llistaRevistes;
	}
	/**
	 * Getter
	 * @return numero de revistes
	 */
	public int getNumRevistes() {
		return numRevistes;
	}
	/**
	 * Setter
	 * @param numero de revistes
	 */
	public void setNumRevistes(int numRevistes) {
		this.numRevistes = numRevistes;
	}
	/**
	 * Metode que retorna una revista si coincideix amb el titol passat per paramatre
	 * @param titol revista
	 * @return revista segons el titol
	 */
	public Revista revistaSegonsTitol(String titol) {
		boolean existeix = false;
		int i = 0;
		while(i<numRevistes && !existeix){
			if(llistaRevistes[i].getTitol().equals(titol)) {
				existeix = true;
			}
			else
				i++;
		}
		if(!existeix)
			return null;
		else
			return llistaRevistes[i].copia();
	}
	/**
	 * Metode per afegir una revista a la llista
	 * @param revista
	 */
	public void afegirRevista(Revista revista) {
		int pos;
		try {		
			llistaRevistes[numRevistes] = revista;
			numRevistes++;
		} catch (ArrayIndexOutOfBoundsException e) {
			Revista[] aux = new Revista[numRevistes * 2];
			
			for (pos = 0; pos < numRevistes; pos++) 
				aux[pos] = llistaRevistes[pos];
			aux[pos] =revista;
			llistaRevistes = aux;
			numRevistes++;
		}
	}
	/**
	 * Metode que retorna una copia de la revista de la posicio de la llista
	 * indicada per parametre
	 * @param posicio de la llista
	 * @return revista de la llista[po]
	 */
	public Revista getRevista(int pos) {
		try {
			return(llistaRevistes[pos].copia());
		} catch (NullPointerException e) {
			System.out.println("No hi ha cap revista en aquesta posici�");
			return null;
		}
	}
	/**
	 * Metode per mostrar la informacio de les revistes de la llista
	 */
	public String toString() {
		String aux= "LLISTA DE REVISTES: N�mero de revistes==> "+numRevistes +"\n"; 
		for(int i=0; i<numRevistes; i++)
			aux = aux + "\n" +llistaRevistes[i].toString()+ "\n";
		return(aux);
	}
}
