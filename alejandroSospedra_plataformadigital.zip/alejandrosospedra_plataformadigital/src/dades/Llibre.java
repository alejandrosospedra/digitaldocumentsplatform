package dades;

public class Llibre extends DocumentsDigitals{
	
	private final static String tipusId="LLIBRE_";
	private static int contadorId=0;
	private String codiId;
	private String autor;
	/**
	 * Constructor general
	 * @param temes
	 */
	public Llibre (LlistaTemes temes) {
		super(temes);
		autor="";
	}
	/**
	 * Constructor de un llibre per a tasques com afegir un llibre a una llista
	 * @param titol del llibre
	 * @param temes en els que es classifica el llibre
	 * @param autor del llibre
	 */
	public Llibre(String titol, LlistaTemes temes, String autor) {
		super(titol, temes);
		contadorId++;
		setCodiId(tipusId+contadorId);
		this.autor=autor; 
	}
	/**
	 * Constructor de un llibre que no modifica el seu codi identificador original
	 * i ens serveix per generar copies d'aquest
	 * @param titol
	 * @param temes
	 * @param autor
	 * @param codiId ==> codi identificador(LLIBRE_+numero de llibres)
	 */
	public Llibre(String titol, LlistaTemes temes, String autor, String codiId) {
		super(titol, temes);
		this.autor=autor;
		setCodiId(codiId);
	}
	/**
	 * Constructor de un llibre que no modifica el seu codi identificador per
	 * incrementa el contador perque serveix per llegir d'un fitxer i posteriorment
	 * poder afegir un llibre en el numero que li pertoca
	 * @param codiId
	 * @param titol
	 * @param temes
	 * @param autor
	 */
	public Llibre(String codiId, String titol, LlistaTemes temes, String autor) {
		super(titol, temes);
		this.autor=autor;
		setCodiId(codiId);
		contadorId++;
	}
	/**
	 * Getter
	 * @return autor
	 */
	public String getAutor() {
		return autor;
	}
	/**
	 * Setter
	 * @param autor
	 */
	public void setAutor(String autor) {
		this.autor = autor;
	}

	public static String getTipusid() {
		return tipusId;
	}
	/**
	 * Getter
	 * @return codi identificador
	 */
	public String getCodiId() {
		return codiId;
	}
	/**
	 * Setter
	 * @param codiId
	 */
	public void setCodiId(String codiId) {
		this.codiId = codiId;
	}
	/**
	 * Metode per mostrar per pantalla el contingut dels atributs de llibre
	 */
	public String toString() {
		String aux;
		aux="Codi identificador: "+getCodiId()+"\nTitol: "+super.titol+"\nAutor: "+autor+"\n"+super.temes.toString();
		return(aux);
	}
	/**
	 * Metode per enviar una copia del llibre
	 * @return llibre
	 */
	public Llibre copia() {
		return(new Llibre (getTitol(), temes, autor, codiId));
	}


}
