package consola;

import java.io.*;
import java.util.*;

import dades.*;

public class apliacioConsola {
	
	static Scanner teclat = new Scanner(System.in);
	/**
	 * Main de la aplicacio de la consola
	 */
	public static void main(String[] args) throws IOException {
		boolean llegit = false; 
		int opcio = 0;
		LlistaRevistes revistes = new LlistaRevistes(20);
		LlistaLlibres llibres = new LlistaLlibres(20);
		
		//Llegim el contingut del fitxers a les llistes corresponents
		FitxerDocDigital.llegirLlibres(llibres);
		FitxerDocDigital.llegirRevistes(revistes);
		
		mostraMenu();
		while(!llegit) {
			try {
				opcio = Integer.parseInt(teclat.nextLine().trim());
				llegit = true;
			} catch (NumberFormatException e) {
				System.out.println("\n\tError! Escriu un nombre sencer.");
			}
		}
		
		while (opcio != 6) {
			switch (opcio) {
			case 1:
				afegirLlibre(llibres);
				break;
			case 2:
				afegirRevista(revistes);
				break;
			case 3:
				afegirExemplar(revistes);
				break;
			case 4:
				consultarDadesProductes(llibres, revistes);
				break;
			case 5:
				consultarProductesTema(llibres, revistes);
				break;
			case 6:
				break;
			default:
				System.out.print("\nSi us plau, introdueixi una opci� v�lida: ");
			}
			llegit = false;
			mostraMenu();
			while (!llegit) {
				try {
					opcio = Integer.parseInt(teclat.nextLine().trim());
					llegit = true;
				} catch (NumberFormatException e) {
					System.out.println("\n\tError! Escriu un nombre sencer del 1 al 6");
				}
			}
		}
		//Quan sortim del programa amb la opcio 6 guardem el contingut de la llista als fitxers
		FitxerDocDigital.escriureLlibres(llibres);
		FitxerDocDigital.escriureRevista(revistes);
		System.out.println("\nInformaci� guardada correctament");
		System.out.print("\nSortint del programa...");
	}
	/**
	 * Metode per consultar la informacio general de les revistes i llibres
	 * de un tema especificat per l'usurari
	 * @param llista de llibres
	 * @param llista de revistes
	 */
	private static void consultarProductesTema(LlistaLlibres llibres, LlistaRevistes revistes) {
		System.out.println("\nIndica el tema del vols consultar els documents digitals: ");
		String tema = teclat.nextLine();
		for(int i=0; i<llibres.getNumLlibres(); i++) {
			if(llibres.getLlibre(i).getTemes().conteTema(tema))
				System.out.println(llibres.getLlibre(i).toString());
		}
		for(int j=0; j<revistes.getNumRevistes(); j++) {
			if(revistes.getRevista(j).getTemes().conteTema(tema))
				System.out.println(revistes.getRevista(j).toStringInfoGeneral());
		}
	}
	/**
	 * Metode per consultar la informacio de tots els documents digitals
	 * @param llista de llibres
	 * @param  llista de revistes
	 */
	private static void consultarDadesProductes(LlistaLlibres llibres, LlistaRevistes revistes) {
		System.out.println(llibres.toString());
		System.out.println(revistes.toString());
		
	}
	/**
	 * Metode per afegir un exemplar a la revista que coincideixi amb el titol
	 * que dona el usuari
	 * @param revistes
	 */
	private static void afegirExemplar(LlistaRevistes revistes) {
		try {
		System.out.println("\nDe quina revista vols afegir l'exemplar? ");
		String titol = teclat.nextLine();
		Revista revista = revistes.revistaSegonsTitol(titol);
		System.out.println("\nAny de l'exemplar: ");
		int any = teclat.nextInt();
		if(any>2018)
			throw new DataNoValidaExcepcio();
		System.out.println("\nMes de l'exemplar: ");
		int mes = teclat.nextInt();
		revista.getLlistaExemplars().afegirExemplar( new Exemplar(any, mes));
		}catch(DataNoValidaExcepcio e) {
			System.out.println(e.toString());
		}
	}
	/**
	 * Metode per afegir una revista a la llista de revistes
	 * @param revistes
	 */
	private static void afegirRevista(LlistaRevistes revistes) {
		System.out.print("\nTitol de la revista: ");
		String titol = teclat.nextLine();
		System.out.println("\nPeriodicitat: ");
		String periodicitat= teclat.nextLine();
		System.out.println("\nIndica el temes separats per comes: ");
		String temes = teclat.nextLine();
		StringTokenizer st = new StringTokenizer(temes, ",");
		LlistaTemes llistaTemes = new LlistaTemes();
		while(st.hasMoreTokens()) {
			llistaTemes.afegirTema(st.nextToken());
		}
		revistes.afegirRevista(new Revista(titol, llistaTemes, periodicitat));
		
	}
	/**
	 * Metode per afegir un llibre a la llista de llibres
	 * @param llibres
	 */
	private static void afegirLlibre(LlistaLlibres llibres) {
		System.out.print("\nTitol del llibre: ");
		String titol = teclat.nextLine();
		System.out.println("\nAutor/s: ");
		String autor= teclat.nextLine();
		System.out.println("\nIndica el temes separats per comes: ");
		String temes = teclat.nextLine();
		StringTokenizer st = new StringTokenizer(temes, ",");
		LlistaTemes llistaTemes = new LlistaTemes();
		while(st.hasMoreTokens()) {
			llistaTemes.afegirTema(st.nextToken());
		}
		llibres.afegirLlibre(new Llibre(titol, llistaTemes, autor));
	}
	/**
	 * Metode per mostrar el menu d'opcions per consola
	 */
	private static void mostraMenu() {
		System.out.println("\nOpcions del menu: ");
		System.out.println("\n\t1. Afegir un llibre");
		System.out.println("\t2. Afegir una revista");
		System.out.println("\t3. Afegir un exemplar");
		System.out.println("\t4. Consultar les dades de tots el Documents Digitals");
		System.out.println("\t5. Consultar les dades dels Documents Digitals d'un tema");
		System.out.println("\t6. Sortir del programa i guardar l'informaci�");
		System.out.print("\n\t\tIndica una opci�: ");
	}

}
